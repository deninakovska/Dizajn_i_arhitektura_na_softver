package com.example.demo.services;

import com.example.demo.entity.HistoricalDataEntity;

import java.util.List;

public interface HistoricalDataService {

    List<HistoricalDataEntity> listAllHistoricalData();
    List<HistoricalDataEntity> findHistoricalDataByCompanyId(Long companyId);
}
