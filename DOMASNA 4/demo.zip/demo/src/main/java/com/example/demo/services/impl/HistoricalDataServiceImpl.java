package com.example.demo.services.impl;

import com.example.demo.entity.HistoricalDataEntity;
import com.example.demo.repository.HistoricalDataRepository;
import com.example.demo.services.HistoricalDataService;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class HistoricalDataServiceImpl implements HistoricalDataService {
    private final HistoricalDataRepository historicalDataRepository;

    public HistoricalDataServiceImpl(HistoricalDataRepository historicalDataRepository) {
        this.historicalDataRepository = historicalDataRepository;
    }

    @Override
    public List<HistoricalDataEntity> listAllHistoricalData() {
        return historicalDataRepository.findAll();
    }

    @Override
    public List<HistoricalDataEntity> findHistoricalDataByCompanyId(Long companyId) {
        return historicalDataRepository.findAllByCompanyId(companyId);
    }
}
