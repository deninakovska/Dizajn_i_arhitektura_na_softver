package com.example.demo.data.pipeline.strategy;

import com.example.demo.entity.CompanyEntity;

import java.io.IOException;
import java.text.ParseException;

public interface DataExtractionStrategy {
    void extractData(CompanyEntity company) throws IOException, ParseException;
}
