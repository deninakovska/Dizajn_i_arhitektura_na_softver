package com.example.demo.web;

import com.example.demo.entity.HistoricalDataEntity;
import com.example.demo.repository.HistoricalDataRepository;
import com.example.demo.services.HistoricalDataService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/data")
public class HistoricalDataController {

    private final HistoricalDataService historicalDataService;

    public HistoricalDataController(HistoricalDataService historicalDataService) {
        this.historicalDataService = historicalDataService;
    }

    @GetMapping("/")
    public List<HistoricalDataEntity> listAllData() {
        return historicalDataService.listAllHistoricalData();
    }

    @GetMapping("/company/{companyId}")
    public List<HistoricalDataEntity> findAllByCompanyId(@PathVariable Long companyId) {
        return historicalDataService.findHistoricalDataByCompanyId(companyId);
    }
}