package com.example.demo.data.pipeline.strategy;

import com.example.demo.entity.CompanyEntity;
import java.io.IOException;
import java.util.List;

public interface CompanyExtractionStrategy {
    List<CompanyEntity> extractCompanies() throws IOException;
}
