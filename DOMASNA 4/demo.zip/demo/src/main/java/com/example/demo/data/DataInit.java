package com.example.demo.data;


import com.example.demo.data.pipeline.Pipe;
import com.example.demo.data.pipeline.impl.CompanyExtractionFilter;
import com.example.demo.data.pipeline.impl.DataExtractionFilter;
import com.example.demo.data.pipeline.strategy.CompanyExtractionStrategy;
import com.example.demo.data.pipeline.strategy.CompanyExtractionStrategyImpl;
import com.example.demo.data.pipeline.strategy.DataExtractionStrategy;
import com.example.demo.data.pipeline.strategy.DataExtractionStrategyImpl;
import com.example.demo.entity.CompanyEntity;
import com.example.demo.repository.CompanyRepository;
import com.example.demo.repository.HistoricalDataRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

@Component
public class DataInit {

    private final CompanyRepository companyRepository;
    private final HistoricalDataRepository historicalDataRepository;

    public DataInit(CompanyRepository companyRepository, HistoricalDataRepository historicalDataRepository) {
        this.companyRepository = companyRepository;
        this.historicalDataRepository = historicalDataRepository;
    }

    @PostConstruct
    private void initializeData() throws IOException, ParseException {
        long startTime = System.nanoTime();

        CompanyExtractionStrategy companyExtractionStrategy = new CompanyExtractionStrategyImpl(companyRepository);
        DataExtractionStrategy dataExtractionStrategy = new DataExtractionStrategyImpl(historicalDataRepository, companyRepository);
        
        Pipe<List<CompanyEntity>> pipe = new Pipe<>();
        pipe.addFilter(new CompanyExtractionFilter(companyExtractionStrategy));
        pipe.addFilter(new DataExtractionFilter(dataExtractionStrategy));
        pipe.runFilter(null);

        long endTime = System.nanoTime();
        long durationInMillis = (endTime - startTime) / 1_000_000;

        long hours = durationInMillis / 3_600_000;
        long minutes = (durationInMillis % 3_600_000) / 60_000;
        long seconds = (durationInMillis % 60_000) / 1_000;

        System.out.printf("Total time for all filters to complete: %02d hours, %02d minutes, %02d seconds%n",
                hours, minutes, seconds);
    }
}
