package com.example.demo.data.pipeline.impl;

import com.example.demo.data.pipeline.Filter;
import com.example.demo.data.pipeline.strategy.CompanyExtractionStrategy;
import com.example.demo.entity.CompanyEntity;
import java.io.IOException;
import java.util.List;

public class CompanyExtractionFilter implements Filter<List<CompanyEntity>> {

    private final CompanyExtractionStrategy companyExtractionStrategy;

    public CompanyExtractionFilter(CompanyExtractionStrategy companyExtractionStrategy) {
        this.companyExtractionStrategy = companyExtractionStrategy;
    }

    @Override
    public List<CompanyEntity> execute(List<CompanyEntity> input) throws IOException {
        return companyExtractionStrategy.extractCompanies();
    }
}
