package com.example.demo.web;
import com.example.demo.entity.CompanyEntity;
import com.example.demo.entity.HistoricalDataEntity;
import com.example.demo.services.AppService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Controller
@RequestMapping(value = "/api")
public class HomeController {

//    @GetMapping("/homepage")
//    public String showHomePage() {
//        return "home-page";
//    }
//    @GetMapping("/data")
//    public String showDataPage(@RequestParam(required = false) String error,
//                               @RequestParam(name = "id", required = false) Long companyId, Model model) {
//        if(companyId != null) {
//            model.addAttribute("companyId", companyId);
//            model.addAttribute("data", appService.findAllByCompanyId(companyId));
//        } else {
//            model.addAttribute("data", appService.listAllData());
//        }
//        model.addAttribute("companies", appService.listAll());
//        return "data";
//    }

    private final RestTemplate restTemplate;

    private static final String DATA_SERVICE_URL = "http://localhost:8080/api/data/";
    private static final String COMPANY_SERVICE_URL = "http://localhost:8080/api/companies/";

    public HomeController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @GetMapping("/homepage")
    public String showHomePage() {
        return "home-page";
    }

    @GetMapping("/datapage")
    public String showDataPage(@RequestParam(required = false) String error,
                               @RequestParam(name = "id", required = false) Long companyId, Model model) {

        String dataUrl = DATA_SERVICE_URL;
        if (companyId != null) {
            dataUrl += "company/" + companyId;
        }

        List<HistoricalDataEntity> data = restTemplate.getForObject(dataUrl, List.class);
        model.addAttribute("data", data);

        List<CompanyEntity> companies = restTemplate.getForObject(COMPANY_SERVICE_URL, List.class);
        model.addAttribute("companies", companies);

        return "data";
    }

    @GetMapping("/contact")
    public String showContactPage() {
        return "contact";
    }



}
