package com.example.demo.data.pipeline.strategy;

import com.example.demo.entity.CompanyEntity;
import com.example.demo.repository.CompanyRepository;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CompanyExtractionStrategyImpl implements CompanyExtractionStrategy {

    private final CompanyRepository companyRepository;
    private static final String STOCK_MARKET_URL = "https://www.mse.mk/mk/stats/symbolhistory/kmb";

    public CompanyExtractionStrategyImpl(CompanyRepository companyRepository) {
        this.companyRepository = companyRepository;
    }

    @Override
    public List<CompanyEntity> extractCompanies() throws IOException {
        Document document = Jsoup.connect(STOCK_MARKET_URL).get();
        Element selectMenu = document.select("select#Code").first();

        List<CompanyEntity> companyList = new ArrayList<>();
        if (selectMenu != null) {
            Elements options = selectMenu.select("option");
            for (Element option : options) {
                String code = option.attr("value");
                if (!code.isEmpty() && code.matches("^[a-zA-Z]+$")) {
                    if (companyRepository.findByCompanyCode(code).isEmpty()) {
                        CompanyEntity company = new CompanyEntity(code);
                        companyRepository.save(company);
                        companyList.add(company);
                    }
                }
            }
        }
        return companyList;
    }
}
