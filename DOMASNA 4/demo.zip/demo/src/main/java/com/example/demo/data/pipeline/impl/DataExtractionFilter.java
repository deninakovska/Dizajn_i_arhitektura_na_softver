package com.example.demo.data.pipeline.impl;

import com.example.demo.data.DataParser;
import com.example.demo.data.pipeline.Filter;
import com.example.demo.data.pipeline.strategy.DataExtractionStrategy;
import com.example.demo.entity.CompanyEntity;
import com.example.demo.entity.HistoricalDataEntity;
import com.example.demo.repository.CompanyRepository;
import com.example.demo.repository.HistoricalDataRepository;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.text.NumberFormat;
import java.text.ParseException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DataExtractionFilter implements Filter<List<CompanyEntity>> {

    private final DataExtractionStrategy dataExtractionStrategy;

    public DataExtractionFilter(DataExtractionStrategy dataExtractionStrategy) {
        this.dataExtractionStrategy = dataExtractionStrategy;
    }

    @Override
    public List<CompanyEntity> execute(List<CompanyEntity> input) throws IOException, ParseException {
        List<CompanyEntity> updatedCompanies = new ArrayList<>();

        for (CompanyEntity company : input) {
            dataExtractionStrategy.extractData(company);

            updatedCompanies.add(company);
        }

        return updatedCompanies;
    }
}

