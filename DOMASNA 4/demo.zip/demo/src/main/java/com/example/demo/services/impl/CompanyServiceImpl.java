package com.example.demo.services.impl;

import com.example.demo.entity.CompanyEntity;
import com.example.demo.repository.CompanyRepository;
import com.example.demo.services.CompanyService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CompanyServiceImpl  implements CompanyService {

    private final CompanyRepository companyRepository;

    public CompanyServiceImpl(CompanyRepository companyRepository) {
        this.companyRepository = companyRepository;
    }

    @Override
    public List<CompanyEntity> listAllCompanies() {
        return companyRepository.findAll();
    }

    @Override
    public CompanyEntity findCompanyById(Long id) {
        return companyRepository.findById(id).orElse(null);
    }
}
