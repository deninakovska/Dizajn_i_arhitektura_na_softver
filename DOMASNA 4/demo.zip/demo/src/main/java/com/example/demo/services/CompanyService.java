package com.example.demo.services;

import com.example.demo.entity.CompanyEntity;

import java.util.List;

public interface CompanyService {
    List<CompanyEntity> listAllCompanies();
    CompanyEntity findCompanyById(Long id);
}
